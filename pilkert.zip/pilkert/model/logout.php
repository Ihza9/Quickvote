<?php
session_start();
session_destroy();
$site =  'page/auth/login.php'; 	
$url = 'https://experiments.sehatnodev.exp/pilkert/';
echo '<script> '.$message.'window.location="'.$url.'?page='.$site.'";</script>';
?>