DROP TABLE IF EXISTS `datapemilihan`;
CREATE TABLE `datapemilihan` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nik` varchar(16)  NOT NULL,
  `nopemilih` varchar(20)  DEFAULT NULL,
  `id_kandidat` varchar(2)  DEFAULT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`id`),
   UNIQUE KEY `nik` (`nik`)
) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `warga`;
CREATE TABLE `warga` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nik` bigint(16) NOT NULL, 
  `password` varchar(32) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jk` enum('L','P') NOT NULL, 
  `tgl_lahir` date DEFAULT NULL,
  `alamat` text DEFAULT NULL, 
  `hp` varchar(15) NOT NULL,
  `level` varchar(1) NOT NULL, 
  `aktif` enum('Y','T') NOT NULL DEFAULT 'T', 
  PRIMARY KEY (`id`),
  UNIQUE KEY `nik` (`nik`)
) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `warga` (`id`, `nik`, `password`, `nama`, `jk`, `alamat`, `hp`, `level`, `aktif`) VALUES
(1, 1234567890, 'sehatnodev', 'Sehatno Software Development', 'L', 'Perum Puskopad, Jl. Garuda No.3 Puri Kab. Mojokerto','08813581349', '1', 'Y');

DROP TABLE IF EXISTS `kandidat`;
CREATE TABLE `kandidat` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  
  `visi` varchar(100)  DEFAULT NULL,
  `misi` varchar(255)  DEFAULT NULL,  
  `foto` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


