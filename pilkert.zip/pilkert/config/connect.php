<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$userdb = "root";
$passdb = "k7s5a661gxm7";
$namadb = "pilkert";
$url = 'https://experiments.sehatnodev.exp/pilkert/';

$conn = mysqli_connect($host, $userdb, $passdb, $namadb);
if (!$conn) {  die("Connection failed: " . mysqli_connect_error()); }
?>
