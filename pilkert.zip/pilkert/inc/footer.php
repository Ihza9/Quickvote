 <!-- /.content-wrapper -->
        <footer class="main-footer">
            <div class="pull-right hidden-xs">
                <b>Version</b> 2.4.0
            </div>
            <strong>Copyright &copy; 2023 <a href="https://sehatnodev.github.io">SehatnoDev Software Development</a>.</strong> All rights
            reserved.
        </footer>       
    </div>
<script>
    $(document).ready(function() {
        $('.sidebar-menu').tree()
    })
</script>
<!-- jQuery 3 -->

</body>

</html>